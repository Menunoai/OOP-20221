import javax.swing.JOptionPane;
public class Bai2_2_5{
	public static void main(String args[]){
		String strNum1, strNum2;
		String strNotification = "You're just entered: ";
		strNum1 = JOptionPane.showInputDialog(null, 
			"Please input the first number: " , 
			"Input the first number", 
			JOptionPane.INFORMATION_MESSAGE);
		strNotification += strNum1 + " and ";

		strNum2 = JOptionPane.showInputDialog(null, 
			"Please input the second number: " , 
			"Input the second number", 
			JOptionPane.INFORMATION_MESSAGE);
		strNotification += strNum2;
		JOptionPane.showMessageDialog(null, strNotification, 
			"Show two number", JOptionPane.INFORMATION_MESSAGE);

		double num1 = Double.parseDouble (strNum1);
		double num2 = Double.parseDouble (strNum2);

		double add = num1 + num2;
		String phepCong = "Add two number: ";
		phepCong += add;
		JOptionPane.showMessageDialog(null, phepCong,
			"Add two number", JOptionPane.INFORMATION_MESSAGE);

		double sub = num1 - num2;
		String phepTru = "Subtraction two number: ";
		phepTru += sub;
		JOptionPane.showMessageDialog(null, phepTru,
			"Sub two number", JOptionPane.INFORMATION_MESSAGE);

		double mul = num1 * num2;
		String phepNhan = "multiplication two number: ";
		phepNhan += mul;
		JOptionPane.showMessageDialog(null, phepNhan,
			"Mul two number", JOptionPane.INFORMATION_MESSAGE);
			
			
		if(num2!=0){
			double div = num1 / num2;
			String phepChia = "Divide two number: ";
			phepChia += div;
			JOptionPane.showMessageDialog(null, phepChia,
				"Div two number", JOptionPane.INFORMATION_MESSAGE);
		}
		else{
			String phepChia = "Khong the thuc hien phep chia!";
			JOptionPane.showMessageDialog(null, phepChia,
				"Div two number", JOptionPane.INFORMATION_MESSAGE);
		}
		System.exit(0);
	}
}