import java.util.Scanner;
public class Bai6_6 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n, m, a[][], b[][];
		System.out.println("Nhập số hàng: ");
		n = sc.nextInt();
		System.out.println("Nhập số cột: ");
		m = sc.nextInt();
		a = new int[n+1][m+1];
		b = new int[n+1][m+1];
				
		for(int i=1; i<=n; i++) {
			for(int j=1; j<=m; j++) {
				System.out.println("a[" + i + "][" + j + "]: ");
				a[i][j] = sc.nextInt();
			}
		}
		
		for(int i=1; i<=n; i++) {
			for(int j=1; j<=m; j++) {
				System.out.println("b[" + i + "][" + j + "]: ");
				b[i][j] = sc.nextInt();
			}
		}
		
		System.out.println("Ma trận a: ");
		for(int i=1; i<=n; i++) {
			for(int j=1; j<=m; j++) {
				System.out.print(a[i][j] + "\t");
			}
			System.out.println("\n");
		}
		
		System.out.println("Ma trận b: ");
		for(int i=1; i<=n; i++) {
			for(int j=1; j<=m; j++) {
				System.out.print(b[i][j] + "\t");
			}
			System.out.println("\n");
		}
		
	}
}
