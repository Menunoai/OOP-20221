import java.util.Scanner;

public class Bai6_4b {
	public static void main(String[] args) {
		String thang;
		int nam;
		Scanner sc = new Scanner(System.in);
		String str[] = {"January", "Jan.", "Jan", "1", "March", "Mar", "Mar.", "3", "May", "5", "July", "Jul", "7", "August", "Aug.", "Aug", "8", "October", "Oct.", "Oct", "10", "December", "Dec", "Dec.", "12", "April", "Apr.", "Apr", "4", "June", "Jun", "6", "September", "Sep", "Sep.", "9", "November", "Nov.", "Nov", "11", "February", "Feb.", "Feb", "2"};

		int check=0;
		
		do {
			System.out.println("Nhập tháng: ");
			thang = sc.nextLine();
			for(int i=0; i<str.length; i++) {
				if(thang.equals(str[i])==true) {
					check = 1;
					break;
				}
			}
		}while(check == 0);
		
		do {
			System.out.println("Nhập năm: ");
			nam = sc.nextInt();
		}while(nam < 1);
		
		switch (thang) {
			case "January":
			case "Jan.":
			case "Jan":
			case "1":
			case "March":
			case "Mar":
			case "Mar.":
			case "3":
			case "May":
			case "5":
			case "July":
			case "Jul":
			case "7":
			case "August":
			case "Aug.":
			case "Aug":
			case "8":
			case "October":
			case "Oct.":
			case "Oct":
			case "10":
			case "December":
			case "Dec":
			case "Dec.":
			case "12":
				System.out.println("Có 31 ngày");
				break;
			case "April":
			case "Apr.":
			case "Apr":
			case "4":
			case "June":
			case "Jun":
			case "6":
			case "September":
			case "Sep":
			case "Sep.":
			case "9":
			case "November":
			case "Nov.":
			case "Nov":
			case "11":
				System.out.println("Có 30 ngày");
				break;
			case "February":
			case "Feb.":
			case "Feb":
			case "2":
				if((nam % 4==0 && nam %100 !=0)||(nam %400==0)) {
					System.out.println("Có 29 ngày");
				}else {
					System.out.println("Có 28 ngày");
				}
				break;
			default:
				System.out.println("Error!");
				break;
		}
	}
}
