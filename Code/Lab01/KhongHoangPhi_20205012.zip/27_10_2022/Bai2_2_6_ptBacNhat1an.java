import java.util.Scanner;		
public class ptBacNhat1an {
	public static void main(String[] args) {
		// ax + b = 0
        int a, b;
        double x;
        Scanner sc = new Scanner(System.in);
        System.out.println("Nhập a: ");
        a = sc.nextInt();
        System.out.println("Nhập b: ");
        b = sc.nextInt();
        System.out.println("Phương trình bậc nhất: " + a + "x + " + b + " = 0");
        if (a == 0) {
            if (b == 0) {
                System.out.println("Phương trình vô số nghiệm.");
            } else {
                System.out.println("Phương trình vô nghiệm.");
            }
        } else {
            x = (double)(-b / a);
            System.out.println("x = " + x);
        }
    }
}
