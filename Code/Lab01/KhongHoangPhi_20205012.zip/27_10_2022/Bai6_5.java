import java.util.Scanner;

public class Bai6_5 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Nhập n: ");
		int n = sc.nextInt();
		int arr[];
		arr = new int[n];
		for(int i=0; i<arr.length; i++) {
			System.out.println("arr[" + i + "] = ");
			arr[i] = sc.nextInt();
		}
		int sum=0;
		for(int i=0; i<arr.length; i++) {
			sum+=arr[i];
		}
		for(int i=0; i<arr.length; i++) {
			for(int j=i; j<arr.length; j++) {
				if(arr[i] > arr[j]){
					int tmp = arr[i];
					arr[i] = arr[j];
					arr[j] = tmp;
				}
			}
		}
		for(int i=0; i<arr.length; i++) {
			System.out.print(arr[i] + " ");
		}
		System.out.println("\nsum = " + sum);
		System.out.println("TBC = " + (double)(sum/n));
	}
}
