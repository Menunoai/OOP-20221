import javax.swing.JOptionPane;
public class ChoosingOption {
	public static void main(String args[]) {
		int option = JOptionPane.showConfirmDialog(null, "Do you want to chang to the first class ticker?");
		JOptionPane.showConfirmDialog(null, "You're chosen: " +  (option == JOptionPane.YES_OPTION? "Yes" : "No"));
		System.exit(0);
	}
}
