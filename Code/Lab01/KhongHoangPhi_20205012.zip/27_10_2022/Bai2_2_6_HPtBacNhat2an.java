public class HPtBacNhat2an {
	public static void main(String[] args) {
		// a11x1 + a12x2 = b1
		// a21x1 + a22x2 = b2
		double a11, a12, a21, a22, b1, b2;
		double x1, x2;
		double D = a11*a22 - a21*a12;
		double D1 = b1*a22 - b2*a12;
		double D2 = a11*b2 - a21*b1;
		if(D!=0) {
			System.out.println("Nghiệm của HPT:");
			x1 = D1/D;
			System.out.println("x1 = " + x1 );
			x2 = D2/D;
			System.out.println("x2 = " + x2 );
		}
		else if((D==0 && D1 != 0) || (D==0 && D2 != 0)){
			System.out.println("HPT vô nghiệm.");
		}
		else {
			System.out.println("HPT vô số nghiệm.");
		}
	}
}
