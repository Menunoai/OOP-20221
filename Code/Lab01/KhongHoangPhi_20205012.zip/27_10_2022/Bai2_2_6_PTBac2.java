import java.util.Scanner;
public class PTBac2 {
    public static void main(String[] args) {
    	Scanner sc = new Scanner(System.in);
    	double a,b,c, x1, x2;
        System.out.print("a = ");
        a = sc.nextDouble();
        System.out.print("b = ");
        b = sc.nextDouble();
        System.out.print("c = ");
        c = sc.nextDouble();
        
        if (a == 0) {
            if (b == 0) {
                System.out.println("PT vô nghiệm!");
            } else {
                System.out.println("PT có một nghiệm: " + "x = " + (-c/b));
            }
        }
        
        double delta = b*b - 4*a*c;
        if (delta > 0) {
            x1 =(-b + Math.sqrt(delta) / (2*a));
            x2 = (-b - Math.sqrt(delta) / (2*a));
            System.out.println("PT có 2 nghiệm là: " + "\nx1 = " + x1 + "\nx2 = " + x2);
        } 
        else if (delta == 0) {
            x1 = (-b / (2 * a));
            System.out.println("PT có nghiệm kép: " + "x1 = x2 = " + x1);
        } 
        else {
            System.out.println("PT vô nghiệm!");
        }
        
    }
}